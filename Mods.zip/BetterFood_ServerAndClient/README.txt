I've included drinkJarEmpty.png in the files.

If you want the icon to show in game, for a mod that has already added it back to the game, copy this file to whatever mod is adding it, such as District Zero.

The path to copy it to (using the example mod above) is "District Zero\UIAtlases\ItemIconAtlas\"

Updating icons requires you fully exit the game, not just return to the main menu. If you are managing a server, it will require a reboot.

-iSneakyPewPew